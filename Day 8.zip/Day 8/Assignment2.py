try:
    fp = open("prakhar.txt","r")
    fp.write("how are you")
    fp.close()
except IOError:
   print("There is an error in file")


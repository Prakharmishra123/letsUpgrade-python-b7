# Python programe for fibonacci series for m numbers greater than n
lst = [0,1,]
ls = []
def fibonacci(n,m):
    a=0
    b=1
    for i in range(0,n):
        s = 0
        s = a + b
        a = b
        b = s
        lst.append(s)
        if s > n:
            a = lst[i+1]
            b = lst[i+2]
            break
    ls = [b,]
    for p in range(0,m-1):
        s = a + b
        a = b
        b = s
        ls.append(s)
    print(ls)

fibo = fibonacci

fibo(100,10)   
    

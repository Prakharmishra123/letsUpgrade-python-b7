s=0
p=1
q=0
def arm(n,m):
    for n in range(n,m):
        s=0
        q=n
        c=0
        while q>0:
            q=q/10
            q=int(q)
            c=c+1
        q=n
        while q>0:
            p=q%10
            s+=pow(p,c)
            q=q/10
            q= int(q)
        if(s == n):
            yield s
print("All armstrong no. from 0 to 1000 are: ")
print(list(arm(0,1000)))

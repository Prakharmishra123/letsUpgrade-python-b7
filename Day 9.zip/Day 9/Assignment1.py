import unittest
"""
    this program is for unit testing
"""
count = 0
def checkprime(num):
    """
        This function is to check weather a num is prime or not
    """
    count = 0
    for i in range (1, num+1):
        if num%i == 0:
            count+= 1
    if count == 2:
        return True
    else:
        return False

class prime(unittest.TestCase):
    def is_prime(self):
        """
            unit test class
        """
        A = 5
        result = checkprime(A)
        self.assertEquals(result, True)
if __name__ == "__main__":
    unittest.main()

     
